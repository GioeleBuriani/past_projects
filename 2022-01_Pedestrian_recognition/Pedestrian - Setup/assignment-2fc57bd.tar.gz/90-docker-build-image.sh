docker build . -t mp-iv
