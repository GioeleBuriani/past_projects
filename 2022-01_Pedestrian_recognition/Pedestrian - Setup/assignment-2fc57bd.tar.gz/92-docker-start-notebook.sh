docker run -it --rm -v $PWD:/mp-iv -p 8888:8888/tcp --name mp_iv mp-iv:latest
